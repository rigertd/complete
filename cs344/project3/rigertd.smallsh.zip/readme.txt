Author:     David Rigert
Class:      CS344 Winter 2016
Assignment: Program 3 - smallsh

=======================================
PREREQUISITES
=======================================
1. GCC 4.4.7+
2. GNU Make 3.81+

=======================================
SYNTAX
=======================================
To compile the program:
> make

To run the program:
> ./smallsh
