/*************************************************************************
 * Author:                 David Rigert
 * Date Created:           1/4/2015
 * Last Modification Date: 1/4/2015
 * Course:                 CS162_400
 * Assignment:             Lab 1, program 2
 * Filename:               g.h
 *
 * Overview:
 *     This header file includes a prototype for a function that displays
 *     a message to the console indicating it was executed.
 ************************************************************************/

#ifndef G_H
#define G_H

void g();

#endif